ANATOLIAN DAWN — SOURCE TEXT MIRROR
ORIGINAL REPOSITORY PATH: README.txt
ORIGINAL GIT BLOB SHA: 2c3470628d44e1f7d632bcff9ccada4cc345c22b
ORIGINAL SOURCE SHA256: efae9d0136ae31a19628ea397c878e242ebd01a0e959589bea23cd652779c60a
SOURCE SNAPSHOT COMMIT: 23b6f174f0b937b8666a93a860d25739fdccd390
CLASSIFICATION: AUTHORING_REFERENCE
Each L###### prefix is the corresponding ORIGINAL source line number.
The original characters on each line are retained without rewriting.
----------------------------------------------------------------------------------------
L000001 | Anatolian Dawn - Cold War tooltip layout fix v2
L000002 | 
L000003 | Run INSTALL.bat. Target: C:\Program Files (x86)\social_democracy_Anatolian_Dawn
L000004 | 
L000005 | Requires existing tooltip adapter from prior installer and Python 3. Backs up its JavaScript asset before replacing it.
L000006 | 
L000007 | New behavior: replace the value in the original Head of State / Head of Government / Government labels. No duplicate panel and no date/baseline warning. Turkey untouched. Internal default date is 1972-01-01 if game date cannot be read.
L000008 | 
L000009 | If the game uses unusual markup, some values might remain unchanged; script does not overwrite unknown tooltip HTML.
