ANATOLIAN DAWN — SOURCE TEXT MIRROR
ORIGINAL REPOSITORY PATH: README.md
ORIGINAL GIT BLOB SHA: cb650490f646c48247a0fde7c9f5244cc395fa18
ORIGINAL SOURCE SHA256: 46dc71f02cc4a7fc9badbd7c5dcaad9bb39b327715a0c08318ffdeed61747b59
SOURCE SNAPSHOT COMMIT: 23b6f174f0b937b8666a93a860d25739fdccd390
CLASSIFICATION: AUTHORING_REFERENCE
Each L###### prefix is the corresponding ORIGINAL source line number.
The original characters on each line are retained without rewriting.
----------------------------------------------------------------------------------------
L000001 | # Anatolian Dawn: An Alternate History
L000002 | 
L000003 | A political strategy game about CHP in 1970s Turkey, adapted from Autumn Chen’s Social Democracy: An Alternate History.
L000004 | 
L000005 | ## Build
L000006 | 
L000007 | Use Node.js 24. Install dependencies with `npm ci`, then run `npm run build` and `npm test`.
L000008 | The playable build is `out/html/index.html`. GitHub Pages uses `.github/workflows/build.yaml`.
L000009 | Most narrative and state live in `source/`. Custom interface code and media live in `out/html/`; preserve them when building.
L000010 | 
L000011 | `out/html/rules.js` shares economy, faction, cabinet-reset and vote calculations between story actions and displays. Register new literal quality names in `scripts/state-keys.json`; `npm run check` validates compiled Dendry state references, card images and the checked economy helper. See `REPAIR_NOTES.md` for the repair scope and validation.
L000012 | 
L000013 | ## Credits
L000014 | 
L000015 | Original game and DendryNexus: Autumn Chen. Turkish adaptation: Egehan.
L000016 | Upstream repository: https://github.com/aucchen/social_democracy_alternate_history
L000017 | See LICENSE, the in-game credits, credits_images.txt and credits_music.txt for attribution.
L000018 | The historical changes.txt file records upstream development and is retained as provenance.
L000019 | 
L000020 | ## Save compatibility
L000021 | 
L000022 | The Weimar-remnant cleanup renames state and scene IDs. Start a new playthrough after updating; pre-cleanup saves are not supported.
