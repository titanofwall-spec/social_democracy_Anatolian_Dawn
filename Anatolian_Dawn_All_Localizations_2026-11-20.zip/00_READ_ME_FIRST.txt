ANATOLIAN DAWN — COMPLETE LOCALIZATION SOURCE EXPORT
===================================================

GAME REPOSITORY
https://github.com/titanofwall-spec/social_democracy_Anatolian_Dawn

EXACT SOURCE COMMIT
23b6f174f0b937b8666a93a860d25739fdccd390

READ THIS FIRST
This ZIP inventories EVERY Git-tracked text-bearing source file in the checkout.
It is designed to make omissions auditable, not merely to list the game's
dedicated localization keys.

LOCALIZATIONS/
    01: Every original event scene and historical narrative (.dry).
    02: Advisor dialogue and advisor scenes.
    03: Card/action/mechanics/coalition scene material and qdisplays.
    04: All strings from the compiled out/html/game.json, with JSON key paths.
    05: Other active runtime JSON data.
    06: Tooltips and government display strings from active JavaScript.
    07: Mechanics, elections, Cyprus, coalitions, action cards and systems UI.
    08: Remaining active runtime UI strings, HTML visible text and attributes.
    09: Non-current backups, test scripts, and supporting source strings.
    10: Reference/authoring notes, clearly marked as not necessarily deployed.
    12: Textual values from any tracked Excel workbook, if found.

SOURCE_MIRROR/
    Separate UTF-8 TXT mirror of EVERY tracked text/code file, including
    unusual/dynamic text a static extractor could overlook. Each one names
    its exact repository-relative path, commit, Git blob SHA, SHA256, class,
    and ORIGINAL 1-based line numbers. The mirror is the completeness audit.

00_MANIFEST.tsv
    Full index of source paths, category, byte length, original line count,
    extraction count, Git SHA, SHA256, and corresponding mirror document.
00_NON_TEXT_ASSETS.tsv
    All omitted media/binary files and their exact source paths.
00_AUDIT.json
    Full file counts and any parsing/encoding warnings.

EXACT IN-GAME LOCATIONS
Every location is repository-relative: 'out/html/foo.js:L52' means line 52
of the deployed file; 'source/scenes/events/foo.scene.dry:L22' means line 22
of the source file. JSON_PATH records identify the exact nested JSON key
or array index, and the source mirror gives its original file lines too.

CURRENT VS OLD
ACTIVE_* paths under source/ and out/html/ are current sources/runtime.
ARCHIVED_BACKUP and DEVELOPMENT_ONLY entries are labeled separately so
historical copies cannot be confused with the deployed text.

TEMPLATES AND GENERATED TEXT
Conditional phrases and JS templates are exported in source form, including
their branches and interpolations. Rendering every possible runtime variable
combination is not feasible without executing all game states. Source code
mirrors preserve the logic and source fragments for all such combinations.

SCOPE OF THE WORD 'EVERY'
The source and exact strings from every tracked readable text/code file are
included; localizations represented ONLY as pixels in images, audible speech
in music, or untracked/private files are not interpretable as code strings.
Those media files are listed, not silently omitted. Source files are never
modified during this export.

COUNTS
Tracked files: 747
Text files mirrored: 473
Original .dry files: 249
JSON string values: 58728
JS/HTML/CSS/etc quoted literal tokens: 48468
XLSX string values: 10
Warnings: 0

If a parser misses unusual markup, find the original exact contents in
SOURCE_MIRROR/ and locate its exact path using 00_MANIFEST.tsv.
